package com.foxstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoxstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
