package com.foxstore.repository;

import com.foxstore.model.Usuario;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface UsuarioRepository extends CrudRepository<Usuario, Integer> {
    @Query(value = "SELECT CASE WHEN count(1) > 0 THEN 'true' ELSE 'false ' END  FROM usuarios WHERE id = :id", nativeQuery = true)
    public boolean exist(int id);
}
