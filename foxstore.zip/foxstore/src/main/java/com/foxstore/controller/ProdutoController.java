package com.foxstore.controller;

import com.foxstore.model.Categoria;
import com.foxstore.model.Produto;
import com.foxstore.model.Usuario;
import com.foxstore.repository.CategoriaRepository;
import com.foxstore.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;

@Controller
public class ProdutoController {
    @Autowired
    private ProdutoRepository produtoRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    @GetMapping("/produtos")
    public String index(Model model){

        List<Produto> produtos = (List<Produto>) produtoRepository.findAll();
        model.addAttribute("produtos", produtos);

        return "produtos/index";
    }

    @GetMapping("/produtos/novo")
    public String novoProduto(){
        return "produtos/novo";
    }
    @PostMapping("/produtos/criar")
    public String criarProduto(Produto produto){

        produtoRepository.save(produto);
        return "redirect:/produtos";
    }

    @GetMapping("/produtos/{id}/excluir")
    public String excluirProduto(@PathVariable int id){
        produtoRepository.deleteById(id);
        return "redirect:/produtos";
    }

    @GetMapping("/produtos/{id}")
    public String buscarProduto(@PathVariable int id, Model model){

        Optional<Produto> product = produtoRepository.findById(id);

        try {
            model.addAttribute("produto", product.get());
        }catch(Exception err) {
            return "redirect:/produtos";
        }
        return "/produtos/editar";
    }

    @PostMapping("/produtos/{id}/atualizar")
    public String atualizarProduto(@PathVariable int id, Produto produto) {
        if (!produtoRepository.exist(id)){
            return "redirect:/produto";
        }

        produtoRepository.save(produto);

        return "redirect:/produtos";

    }
}
