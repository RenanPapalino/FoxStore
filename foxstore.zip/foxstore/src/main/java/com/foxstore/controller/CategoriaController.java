package com.foxstore.controller;

import com.foxstore.model.Categoria;
import com.foxstore.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Optional;

@Controller
public class CategoriaController {
    @Autowired
    private CategoriaRepository categoriaRepository;

    @GetMapping("/categorias")
    public String index(Model model){

        List<Categoria> categoria = (List<Categoria>) categoriaRepository.findAll();
        model.addAttribute("categorias", categoria);

        return "categorias/index";
    }

    @GetMapping("/categorias/novo")
    public String novoCategoria(){
        return "categorias/novo";
    }
    @PostMapping("/categorias/criar")
    public String criarUsuario(Categoria categoria){

        categoriaRepository.save(categoria);

        return "redirect:/categorias";
    }

    @GetMapping("/categorias/{id}/excluir")
    public String excluirCategoria(@PathVariable int id){
        categoriaRepository.deleteById(id);
        return "redirect:/categorias";
    }

    @GetMapping("/categorias/{id}")
    public String buscarCategoria(@PathVariable int id, Model model){

        Optional<Categoria> category = categoriaRepository.findById(id);

        try {
            model.addAttribute("categoria", category.get());
        }catch(Exception err) {
            return "redirect:/categorias";
        }
        return "/categorias/editar";
    }

    @PostMapping("/categorias/{id}/atualizar")
    public String atualizarCategoria(@PathVariable int id, Categoria categoria) {
       // if (!categoriaRepository.exist(id)){
        if (!categoriaRepository.existsById(id)){
            return "redirect:/categorias";
        }
        categoriaRepository.save(categoria);

        return "redirect:/categorias";
    }
}
