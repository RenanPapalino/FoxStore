package com.foxstore.controller;

import com.foxstore.model.Usuario;
import com.foxstore.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Optional;

@Controller
public class UsuarioController {
    @Autowired
   private UsuarioRepository usuarioRepository;

        @GetMapping("/usuarios")
        public String index(Model model){

            List<Usuario> usuarios = (List<Usuario>) usuarioRepository.findAll();
            model.addAttribute("usuarios", usuarios);

            return "usuarios/index";
        }

        @GetMapping("/usuarios/novo")
        public String novoUsuario(){
            return "usuarios/novo";
        }
        @PostMapping("/usuarios/criar")
        public String criarUsuario(Usuario usuario){

            usuarioRepository.save(usuario);
            return "redirect:/usuarios";
        }

        @GetMapping("/usuarios/{id}/excluir")
        public String excluirUsuario(@PathVariable int id){
            usuarioRepository.deleteById(id);
            return "redirect:/usuarios";
        }

        @GetMapping("/usuarios/{id}")
        public String buscarUsuario(@PathVariable int id, Model model){

            Optional<Usuario> user = usuarioRepository.findById(id);

            try {
                model.addAttribute("usuario", user.get());
            }catch(Exception err) {
               return "redirect:/usuarios";
            }
            return "/usuarios/editar";
        }

        @PostMapping("/usuarios/{id}/atualizar")
        public String atualizarUsuario(@PathVariable int id, Usuario usuario) {
            if (!usuarioRepository.exist(id)){
                return "redirect:/usuarios";
            }

            usuarioRepository.save(usuario);

            return "redirect:/usuarios";
        }
}
