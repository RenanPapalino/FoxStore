package com.foxstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoxstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoxstoreApplication.class, args);
	}

}
